export default function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>つもり貯金DAO（React版）</h1>
      <p>ここに機能を入れていきます。</p>
    </div>
  )
}